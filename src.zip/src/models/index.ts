// models/index.ts
export * from './patient'
export * from './booking'
