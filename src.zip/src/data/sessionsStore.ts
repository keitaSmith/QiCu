import type { Session } from '@/models/session'

// shared in-memory store for all sessions
export const sessionsStore: Session[] = []
