// data/index.ts
export * from './patients'
export * from './bookings'
